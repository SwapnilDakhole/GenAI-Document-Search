import os
from langchain_community.document_loaders import DirectoryLoader
from langchain_community.embeddings import OpenAIEmbeddings
from langchain_community.vectorstores import Pinecone as LangchainPinecone
from langchain.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from app.config import INDEX_NAME, MODEL_NAME
from langchain.text_splitter import RecursiveCharacterTextSplitter


# Initialize embeddings
embeddings = OpenAIEmbeddings(model="text-embedding-ada-002")

# Initialize the ChatOpenAI model
llm = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=os.getenv("OPENAI_API_KEY"))

# Define your custom prompt template for the QA chain
prompt_template = """You are a helpful assistant. Based on the provided documents, answer the following question.
Documents:
{documents}
Question: {question}
Answer:"""

# Set up the prompt template
prompt = PromptTemplate(template=prompt_template, input_variables=["documents", "question"])

# Create a RunnableSequence for input/output processing
llm_chain = LLMChain(prompt=prompt, llm=llm, verbose=True)

# Function to load and split documents for indexing
def load_and_split_docs(directory: str, chunk_size=1000, chunk_overlap=20):
    """Load documents from a directory and split them into chunks."""
    loader = DirectoryLoader(directory)
    documents = loader.load()
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    return text_splitter.split_documents(documents)

# Function to initialize the Pinecone index with document embeddings
def initialize_pinecone_index(docs):
    """Initialize or update the Pinecone index with document embeddings."""
    pinecone_index = LangchainPinecone.from_documents(docs, embeddings, index_name=INDEX_NAME)
    return pinecone_index

# Function to search similar documents based on the query
def search_similar_docs(query: str, k: int = 2, score: bool = False):
    """Search for similar documents based on the query."""
    index = LangchainPinecone.from_existing_index(index_name=INDEX_NAME, embedding=embeddings)
    return index.similarity_search_with_score(query, k=k) if score else index.similarity_search(query, k=k)

# Function to generate an answer based on similar documents
def generate_answer(query: str, similar_docs):
    """Generate an answer to the query based on similar documents."""
    return llm_chain.invoke({"documents": similar_docs, "question": query})
