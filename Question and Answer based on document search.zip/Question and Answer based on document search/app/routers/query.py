from fastapi import APIRouter, HTTPException
from app.services import search_similar_docs, generate_answer

router = APIRouter()

@router.get("/query/")
async def query_pinecone(query: str, k: int = 2, score: bool = False):
    """Endpoint to query similar documents and generate an answer."""
    try:
        # Perform similarity search
        similar_docs = search_similar_docs(query, k=k, score=score)
        
        # Generate answer using similar documents
        answer = generate_answer(query, similar_docs)
        return {"query": query, "answer": answer}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))