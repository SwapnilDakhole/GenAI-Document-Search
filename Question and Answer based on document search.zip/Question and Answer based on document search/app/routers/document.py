import logging
from typing import List

from fastapi import APIRouter, File, HTTPException, UploadFile

from app.services import initialize_pinecone_index, load_and_split_docs
from app.utils import save_uploaded_files

router = APIRouter()


@router.post("/upload/")
async def upload_files(files: List[UploadFile] = File(...)):
    """Endpoint to upload files, process and store their embeddings in Pinecone."""
    try:
        # Save uploaded files and load documents
        directory = save_uploaded_files(files)
        documents = load_and_split_docs(directory)

        # Initialize or update Pinecone index
        initialize_pinecone_index(documents)
        return {
            "message": "Files uploaded and processed successfully",
            "documents_processed": len(documents),
        }
    except Exception as e:
        logging.error(f"Pinecone initialization failed: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
