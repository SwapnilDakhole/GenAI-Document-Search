import requests
import streamlit as st

API_URL = "http://127.0.0.1:8000/search/query/"

st.set_page_config(page_title="Document search")

st.title("📚 Question Answering System")


query = st.text_input(
    "Ask a question:", placeholder="e.g., What are the services provided by Cybage?"
)

if st.button("Get Answer"):
    if query:
        with st.spinner("Fetching response..."):
            try:

                response = requests.get(API_URL, params={"query": query})

                if response.status_code == 200:
                    data = response.json()
                    final_answer = data.get("answer", {}).get(
                        "text", "No answer found."
                    )

                    st.subheader("Answer:")
                    st.success(final_answer)
                else:
                    st.error(f"Error: {response.status_code} - {response.text}")

            except Exception as e:
                st.error(f"Failed to get a response: {str(e)}")
    else:
        st.warning("Please enter a question.")
