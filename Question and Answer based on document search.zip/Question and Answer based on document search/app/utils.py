import logging
import os

from fastapi import UploadFile


def save_uploaded_files(
    files: list[UploadFile], upload_dir: str = "/tmp/uploaded_files"
) -> str:
    os.makedirs(upload_dir, exist_ok=True)
    for file in files:
        file_path = os.path.join(upload_dir, file.filename)
        logging.info(f"Saving file to {file_path}")
        with open(file_path, "wb") as f:
            f.write(file.file.read())

        if not os.path.exists(file_path):
            logging.error(f"File {file.filename} not saved correctly")
    return upload_dir
