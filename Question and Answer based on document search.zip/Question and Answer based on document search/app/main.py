from fastapi import FastAPI
from app.routers import document, query

app = FastAPI(
    title="LangChain Document Processing API",
    description="An API to upload documents, search for similar documents, and answer questions.",
    version="1.0.0",
)

app.include_router(document.router, prefix="/documents", tags=["Document Upload"])
app.include_router(query.router, prefix="/search", tags=["Query and Answer"])

# Run the app using `uvicorn app.main:app --reload`